from django.db import models

from rest_framework import serializers

from dashboard.models import Message
from pills.models import ActivePill, Pills, Stock


class MessageSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Message
        fields = ["title", "description", "note", "status"]

    def create(self, validated_data):
        messages = Message.objects.create(
            title=validated_data["title"],
            description=validated_data["description"],
            note=validated_data["note"],
            status=validated_data["status"]
        )

        return messages


class PillsStockUpdateSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Pills
