from rest_framework import generics, permissions, serializers, status
from rest_framework.response import Response

from pills.models import Pills

from .serializers import MessageSerializer, PillsStockUpdateSerializer


class MessageCreate(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = MessageSerializer

    def post(self, request, format=None):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PillStockUpdate(generics.UpdateAPIView):
    queryset = Pills.objects.all()
    permission_classes = (permissions.AllowAny,)
    serializer_class = PillsStockUpdateSerializer
    lookup_field = 'pk'

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.stock.last_amount = instance.stock.amount
        instance.stock.amount = request.data.get("amount")
        instance.save()

        serializer = self.get_serializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        return Response(serializer.data)
