from django.urls import path

from rest_framework import routers

from . import views

urlpatterns = [
    path("message/create", views.MessageCreate.as_view(), name="api_message_create"),
    path(
        "pills/amount/update/<int:pk>",
        views.PillStockUpdate.as_view(),
        name="api_pill_stock_update",
    ),
]
