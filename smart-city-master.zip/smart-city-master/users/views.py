from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import redirect, render
from django.views.generic import CreateView

from .forms import UserRegisterForm


def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            first_name = form.cleaned_data.get("first_name")
            last_name = form.cleaned_data.get("last_name")
            messages.success(
                request, f"Account voor {first_name} {last_name} aangemaakt!"
            )
            return redirect("frontend-home")
    else:
        form = UserRegisterForm()
        return render(request, "registration/register.html", {"form": form})
