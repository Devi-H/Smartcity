from django.utils.translation import gettext_lazy as _


class Days:
    MONDAY = "MON"
    TUESDAY = "TUE"
    WEDNESDAY = "WED"
    THURSDAY = "THU"
    FRIDAY = "FRI"
    SATURDAY = "SAT"
    SUNDAY = "SUN"

    @classmethod
    def choices(cls):
        return (
            (cls.MONDAY, _("Maandag")),
            (cls.TUESDAY, _("Dinsdag")),
            (cls.WEDNESDAY, _("Woensdag")),
            (cls.THURSDAY, _("Donderdag")),
            (cls.FRIDAY, _("Vrijdag")),
            (cls.SATURDAY, _("Zaterdag")),
            (cls.SUNDAY, _("Zondag")),
        )
