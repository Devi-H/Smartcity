from django.contrib import admin

# Register your models here.
from .models import ActivePill, Pills, Stock

admin.site.register(Pills)
admin.site.register(ActivePill)
admin.site.register(Stock)