from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _

from .constants import Days


class Pills(models.Model):
    title = models.CharField(
        _("Titel"), max_length=256, blank=False, null=False, unique=True
    )
    description = models.TextField(_("Omschrijving"), blank=True, null=True)
    weight = models.IntegerField(_("Gewicht"), blank=False, null=False)
    amount = models.IntegerField(_("Hoeveelheid"), blank=False, null=False)
    doses = models.IntegerField(_("Dozering"), blank=False, null=False)
    side_effects = models.TextField(_("Bijwerkingen"), blank=True, null=True)

    class Meta:
        verbose_name = _("Pil")
        verbose_name_plural = _("Pillen")

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("pill_detail", kwargs={"pk": self.pk})


class ActivePill(models.Model):
    pill = models.ForeignKey(
        "pills.Pills",
        verbose_name=_("Actieve pil"),
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    day = models.CharField(
        choices=Days.choices(), max_length=256, blank=False, null=False, default="none"
    )

    class Meta:
        verbose_name = _("Actieve pil")
        verbose_name_plural = _("Actieve pillen")

    def __str__(self):
        return f"{self.pill.title} voor dag: {self.get_day_display()}"

    def get_absolute_url(self):
        return reverse("active_pill_detail", kwargs={"pk": self.pk})


class Stock(models.Model):
    pill = models.OneToOneField(
        "pills.Pills",
        verbose_name=_("Pil"),
        on_delete=models.CASCADE,
        blank=False,
        null=False,
    )
    amount = models.IntegerField(_("Voorraad"), blank=False, null=False)
    last_amount = models.IntegerField(_("Voormalige voorraad"), blank=True, null=True)
    max_amount = models.IntegerField(_("Maximale voorraad"), blank=False, null=False)

    class Meta:
        verbose_name = _("Voorraad")
        verbose_name_plural = _("Voorraden")

    def __str__(self):
        return f"Voorraad van {self.pill.title}"

    def get_absolute_url(self):
        return reverse("active_pill_detail", kwargs={"pk": self.pk})

    def type(self):
        if self.amount/self.max_amount >= 0.7:
            return "success"
        if self.amount/self.max_amount < 0.2:
            return "danger"
        if self.amount/self.max_amount < 0.7:
            return "warning"
