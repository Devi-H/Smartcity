"""URL Configuration."""
from django.urls import include, path

from . import views

urlpatterns = [
    path("", views.DashboardIndexView.as_view(), name="dashboard_index"),
    path(
        "actief-medicijn/bewerken/<int:pk>",
        views.ActiveMedicineUpdateView.as_view(),
        name="dashboard_active_medicine_update",
    ),
    path(
        "medicijnen/", views.MedicineListView.as_view(), name="dashboard_medicine_list"
    ),
    path(
        "medicijnen/toevoegen/",
        views.MedicineCreateView.as_view(),
        name="dashboard_medicine_create_view",
    ),
    path(
        "medicijnen/bewerken/<int:pk>",
        views.MedicineUpdateView.as_view(),
        name="dashboard_medicine_update_view",
    ),
    path(
        "medicijnen/<int:pk>/delete",
        views.MedicineDeleteView.as_view(),
        name="dashboard_medicine_delete",
    ),
    path(
        "voorraad/",
        views.StockListView.as_view(),
        name="dashboard_stock_list",
    ),
    path(
        "voorraad/bewerken/<int:pk>",
        views.StockUpdateView.as_view(),
        name="dashboard_stock_update",
    ),
    path(
        "message-center/",
        views.MessageCenterListView.as_view(),
        name="dashboard_message_center",
    ),
]
