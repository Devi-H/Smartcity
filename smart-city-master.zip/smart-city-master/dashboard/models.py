from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _

from .constants import Status


class Message(models.Model):
    title = models.CharField(max_length=256, blank=False, null=False)
    description = models.TextField(_("Description"), blank=True, null=True)
    note = models.TextField(_("Note"), blank=True, null=True)
    status = models.CharField(
        choices=Status.choices(),
        max_length=256,
        blank=False,
        null=False,
        default="none",
    )

    class Meta:
        verbose_name = _("message")
        verbose_name_plural = _("messages")

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("message_detail", kwargs={"pk": self.pk})
