from django import forms

from pills.models import ActivePill, Pills, Stock


class MedicineCreateForm(forms.ModelForm):
    class Meta:
        model = Pills
        fields = ("title", "description", "weight", "amount", "doses", "side_effects")

    def save(self, *args, **kwargs):
        obj = super().save(*args, **kwargs)
        return obj


class MedicineUpdateForm(forms.ModelForm):
    class Meta:
        model = Pills
        fields = ("title", "description", "weight", "amount", "doses", "side_effects")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def save(self, *args, **kwargs):
        obj = super().save(*args, **kwargs)
        return obj


class ActiveMedicineUpdateForm(forms.ModelForm):
    class Meta:
        model = ActivePill
        exclude = ("day",)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def save(self, *args, **kwargs):
        obj = super().save(*args, **kwargs)
        return obj


class StockUpdateForm(forms.ModelForm):
    class Meta:
        model = Stock
        fields = ("amount", "max_amount")
        exclude = ("pill", "last_amount")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def save(self, *args, **kwargs):
        obj = super().save(*args, **kwargs)
        return obj
