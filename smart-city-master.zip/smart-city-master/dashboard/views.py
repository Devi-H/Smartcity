from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from django.utils.translation import gettext as _
from django.views.generic import (
    CreateView,
    DeleteView,
    ListView,
    TemplateView,
    UpdateView,
    View,
)

from pills.models import ActivePill, Pills, Stock

from . import forms
from .models import Message


class DashboardView(View):
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["firstName"] = self.request.user.first_name
        context["lastName"] = self.request.user.last_name
        return context


class DashboardIndexView(LoginRequiredMixin, DashboardView, TemplateView):
    model = ActivePill
    template_name = "dashboard/dashboard.html"
    login_url = "/accounts/login"
    redirect_field_name = ""

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["activePill"] = ActivePill.objects.all()
        return context


class ActiveMedicineUpdateView(LoginRequiredMixin, DashboardView, UpdateView):
    model = ActivePill
    template_name = "dashboard/active_medicine_update.html"
    form_class = forms.ActiveMedicineUpdateForm
    success_url = reverse_lazy("dashboard_index")

    def get(self, *args, **kwargs):
        return super().get(*args, **kwargs)

    def get_context_data(self, **kwargs):
        return super().get_context_data(**kwargs)


class MedicineListView(LoginRequiredMixin, DashboardView, ListView):
    model = Pills
    template_name = "dashboard/medicine_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class MedicineCreateView(LoginRequiredMixin, DashboardView, CreateView):
    model = Pills
    template_name = "dashboard/medicine_create.html"
    form_class = forms.MedicineCreateForm
    success_url = reverse_lazy("dashboard_medicine_list")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["pageTitle"] = "Medicijn toevoegen"
        return context


class MedicineUpdateView(LoginRequiredMixin, DashboardView, UpdateView):
    model = Pills
    template_name = "dashboard/medicine_create.html"
    form_class = forms.MedicineUpdateForm
    success_url = reverse_lazy("dashboard_medicine_list")

    def get(self, *args, **kwargs):
        return super().get(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["pageTitle"] = "Medicijn bewerken"
        return context


class MedicineDeleteView(
    LoginRequiredMixin, SuccessMessageMixin, DashboardView, DeleteView
):
    model = Pills
    template_name = "dashboard/medicine_delete.html"
    succes_message = _("Medicijn is verwijderd")

    def get(self, *args, **kwargs):
        return super().get(*args, **kwargs)

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, self.success_message)
        return super(MedicineDeleteView, self).delete(request, *args, **kwargs)

    def get_success_url(self):
        return reverse_lazy("dashboard_medicine_list")


class StockListView(LoginRequiredMixin, DashboardView, ListView):
    model = Stock
    template_name = "dashboard/stock_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class StockUpdateView(LoginRequiredMixin, DashboardView, UpdateView):
    model = Stock
    template_name = "dashboard/stock_update.html"
    form_class = forms.StockUpdateForm
    success_url = reverse_lazy("dashboard_stock_list")

    def get(self, *args, **kwargs):
        return super().get(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["pageTitle"] = "Voorraad bewerken"
        return context


class MessageCenterListView(LoginRequiredMixin, DashboardView, ListView):
    model = Message
    template_name = "dashboard/message_center_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context
