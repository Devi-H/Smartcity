from django.utils.translation import gettext_lazy as _


class Status:
    SUCCES = "1"
    UNSUCCESFULL = "2"

    @classmethod
    def choices(cls):
        return (
            (cls.SUCCES, _("success")),
            (cls.UNSUCCESFULL, _("danger")),
        )
