"""URL Configuration."""
from django.urls import include, path

from . import views

urlpatterns = [
    path("", views.HomeView.as_view(), name="frontend_home"),
]
